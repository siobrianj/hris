## 0.8.12.0 (2019-05-17)

  - Update assets from Summernote 0.8.10 to 0.8.12
    - https://github.com/summernote/summernote/releases/tag/v0.8.12
    - https://github.com/summernote/summernote/releases/tag/v0.8.11
  - Removed summernote-custom-theme.css & summernote-custom-theme.min.css

## 0.8.10.0 (2018-02-20)

  - Update Bootstrap 4.0.0.beta to Bootstrap 4.0.0
  - https://github.com/summernote/summernote/releases/tag/v0.8.10

## 0.8.9.2 (2018-02-01)

  - Update custom checkbox with Bootstrap 4.0.0 in URL Insert Modal.

## 0.8.9.1 (2018-01-31)

  - Reposition close button in the modal foot to right.
  - Update input focus style in the Insert Image modal form.

## 0.8.9.0 (2018-01-31)

Updates:
  - Update assets to Summernote v0.8.9

Changes:   
  - Changed the path of locales to "//= require summernote/lang/summernote-ko-KR"

## 0.8.8.1 (2018-01-31)

Updates:
  - Update assets to Summernote v0.8.8
  - Add summernote-custom-theme.min.css

## 0.8.3.0 (2017-05-06)

Updates:

  - Update assets to Summernote v0.8.3

Fixed:

  - [Fixed cannot be loaded with Rails 3.1 <=](https://github.com/summernote/summernote-rails/pull/63)

## 0.8.2.0 (2016-11-03)

Updates:

  - Update assets to Summernote v0.8.2

Changes:

  - [Support sprocket 3.x](https://github.com/summernote/summernote-rails/issues/49)

## 0.8.1.0 (2016-01-12)

Updates:

  - Update assets to Summernote v0.8.1

Changes:

  - From summernote version 0.8.0 `font-awesome` is no more needed. remove `font-awesome-rails` gem or `font-awesome` asset.
