module SummernoteRails
  module Rails
    class Railtie < ::Rails::Railtie; end
  end
end