module SummernoteRails
  module Rails
    VERSION = "0.8.12.0"
  end
end
